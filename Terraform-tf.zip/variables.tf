variable "instance_type" {
  default = "t2.micro"
}

variable "ami_id" {
  default = "ami-01f23391a59163da9"
}

variable "bucket_name" {
  default = "super-ticket-s3-bucket"
}

variable "db_instance_identifier" {
  default = "super-ticket-db"
}

variable "db_name" {
  default = "superticket"
}

variable "db_username" {
  default = "admin"
}

variable "db_password" {
  description = "admin132"
  type        = string
  sensitive   = true
}