resource "aws_db_instance" "super_ticket_db" {
  identifier              = var.db_instance_identifier
  engine                  = "mysql"
  instance_class          = "db.t3.micro"
  allocated_storage       = 20
  name                    = var.db_name
  username                = var.db_username
  password                = var.db_password
  skip_final_snapshot     = true
  publicly_accessible     = true
  vpc_security_group_ids  = [aws_security_group.super_ticket_sg.id]
  db_subnet_group_name    = aws_db_subnet_group.default.name

  tags = {
    Name    = "SuperTicket RDS"
    Author  = "José Bertos"
  }
}

resource "aws_db_subnet_group" "default" {
  name       = "default-subnet-group"
  subnet_ids = data.aws_subnet_ids.default.ids

  tags = {
    Name = "Default subnet group"
  }
}
