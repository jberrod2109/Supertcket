resource "aws_s3_bucket" "super_ticket_bucket" {
  bucket = var.bucket_name

  tags = {
    Name        = "SuperTicket S3 Bucket"
    Environment = "production"
    Author      = "José Bertos"
  }
}