output "instance_public_ip" {
  value = aws_instance.super_ticket.public_ip
  description = "Dirección IP pública de la instancia EC2"
}

output "s3_bucket_name" {
  value = aws_s3_bucket.super_ticket_bucket.id
}

output "rds_endpoint" {
  value = aws_db_instance.super_ticket_db.endpoint
  description = "Endpoint de conexión para la base de datos RDS"
}
